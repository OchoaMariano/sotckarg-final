-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:8889
-- Tiempo de generación: 11-12-2022 a las 20:09:13
-- Versión del servidor: 5.7.34
-- Versión de PHP: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `Stock2`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Estado`
--

CREATE TABLE `Estado` (
  `id` int(11) NOT NULL,
  `valor_estado` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `Estado`
--

INSERT INTO `Estado` (`id`, `valor_estado`) VALUES
(1, 'Cancelado'),
(3, 'Pago'),
(2, 'Reservado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Mensaje`
--

CREATE TABLE `Mensaje` (
  `id` int(11) NOT NULL,
  `id_operacion` int(11) DEFAULT NULL,
  `id_remitente` int(11) NOT NULL,
  `id_destinatario` int(11) NOT NULL,
  `mensaje` varchar(255) NOT NULL,
  `fecha` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Operacion`
--

CREATE TABLE `Operacion` (
  `id` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `id_usuario_vendedor` int(11) NOT NULL,
  `id_usuario_comprador` int(11) NOT NULL,
  `id_estado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `Operacion`
--

INSERT INTO `Operacion` (`id`, `id_producto`, `id_usuario_vendedor`, `id_usuario_comprador`, `id_estado`) VALUES
(51, 1, 4, 3, 2),
(52, 1, 4, 3, 2),
(53, 1, 4, 3, 3),
(54, 1, 4, 3, 3),
(55, 1, 4, 3, 2),
(56, 1, 4, 3, 3),
(57, 9, 5, 3, 3),
(58, 9, 5, 3, 2),
(59, 12, 5, 3, 2),
(60, 12, 5, 3, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Producto`
--

CREATE TABLE `Producto` (
  `id` int(11) NOT NULL,
  `nombre` varchar(250) NOT NULL,
  `descripcion` varchar(250) NOT NULL,
  `stock` int(10) NOT NULL,
  `precio` int(11) NOT NULL,
  `fecha` date DEFAULT NULL,
  `id_usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `Producto`
--

INSERT INTO `Producto` (`id`, `nombre`, `descripcion`, `stock`, `precio`, `fecha`, `id_usuario`) VALUES
(1, 'Producto 1', 'Cajas', 12, 20000, '2022-12-01', 4),
(9, 'Producto 2', 'Cajas de plástico', 1000, 40, NULL, 5),
(10, 'Producto 3', 'Cajas de tela', 1320, 45000, NULL, 5),
(11, 'Producto 4', 'Cajas de vidrio', 24, 50000, NULL, 5),
(12, 'Producto 10', 'Sobres', 12, 2500, NULL, 5),
(13, 'Producto 11', 'Botellas', 20, 1200, NULL, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Rol`
--

CREATE TABLE `Rol` (
  `id` int(11) NOT NULL,
  `nombre_rol` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `Rol`
--

INSERT INTO `Rol` (`id`, `nombre_rol`) VALUES
(2, 'Comprador'),
(1, 'Vendedor');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Usuario`
--

CREATE TABLE `Usuario` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telefono` int(10) NOT NULL,
  `password` varchar(20) NOT NULL,
  `direccion` varchar(50) DEFAULT NULL,
  `nombre_usuario` varchar(50) NOT NULL,
  `id_rol` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `Usuario`
--

INSERT INTO `Usuario` (`id`, `nombre`, `apellido`, `email`, `telefono`, `password`, `direccion`, `nombre_usuario`, `id_rol`) VALUES
(2, 'Pablo', 'Gutierrez', 'pablo@gutierrez.com', 1564474415, '123456', '123', 'Pgutierrez', 1),
(3, 'Julian', 'alvarez', 'juli@alvarez.com', 1164474115, '123456', NULL, 'Juli_alvarez', 2),
(4, 'Jorge', 'Test', 'j@jorge.com', 1164474115, '123456', NULL, 'Jorge', 2),
(5, 'Miguel', 'Mail', 'miguel@mail.com', 1164474115, '123456', 'beco 514', 'Miguel', 1),
(7, 'Lucas', 'Rodriguez', 'lucas@rodriguez.com', 1164474115, '123456', 'mayo 123', 'Lucas', 2);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `Estado`
--
ALTER TABLE `Estado`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `valor_estado` (`valor_estado`);

--
-- Indices de la tabla `Mensaje`
--
ALTER TABLE `Mensaje`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_usuario` (`id_remitente`) USING BTREE,
  ADD KEY `id_destinatario` (`id_destinatario`) USING BTREE;

--
-- Indices de la tabla `Operacion`
--
ALTER TABLE `Operacion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `operacion_vendedor` (`id_producto`),
  ADD KEY `id_estado` (`id_estado`),
  ADD KEY `id_usuario_comprador` (`id_usuario_comprador`),
  ADD KEY `id_usuario` (`id_usuario_vendedor`) USING BTREE;

--
-- Indices de la tabla `Producto`
--
ALTER TABLE `Producto`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_usuario` (`id_usuario`) USING BTREE;

--
-- Indices de la tabla `Rol`
--
ALTER TABLE `Rol`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuario_vendedor` (`nombre_rol`);

--
-- Indices de la tabla `Usuario`
--
ALTER TABLE `Usuario`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `id_rol` (`id_rol`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `Estado`
--
ALTER TABLE `Estado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `Mensaje`
--
ALTER TABLE `Mensaje`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT de la tabla `Operacion`
--
ALTER TABLE `Operacion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT de la tabla `Producto`
--
ALTER TABLE `Producto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `Rol`
--
ALTER TABLE `Rol`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `Usuario`
--
ALTER TABLE `Usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `Mensaje`
--
ALTER TABLE `Mensaje`
  ADD CONSTRAINT `id_destinatario` FOREIGN KEY (`id_destinatario`) REFERENCES `Usuario` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `id_remitente` FOREIGN KEY (`id_remitente`) REFERENCES `Usuario` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `Operacion`
--
ALTER TABLE `Operacion`
  ADD CONSTRAINT `id_estado` FOREIGN KEY (`id_estado`) REFERENCES `Estado` (`id`),
  ADD CONSTRAINT `id_producto` FOREIGN KEY (`id_producto`) REFERENCES `Producto` (`id`),
  ADD CONSTRAINT `id_usuario_comprador` FOREIGN KEY (`id_usuario_comprador`) REFERENCES `Usuario` (`id`);

--
-- Filtros para la tabla `Producto`
--
ALTER TABLE `Producto`
  ADD CONSTRAINT `producto_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `Usuario` (`id`);

--
-- Filtros para la tabla `Usuario`
--
ALTER TABLE `Usuario`
  ADD CONSTRAINT `rol` FOREIGN KEY (`id_rol`) REFERENCES `Rol` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
